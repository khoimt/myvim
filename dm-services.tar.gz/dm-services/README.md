# Test
```
mvn clean compile  exec:java -Dexec.mainClass="vn.viettel.fw.bigdata.db.proxy.main.MainEntry" -Dexec.args="conf/app.json"
```


