/**
 * Copyright 2015 Viettel Group. All rights reserved
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.main;

import java.util.concurrent.ExecutorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.com.viettel.subcriberservice.httpserver.HttpServer;
import vn.com.viettel.subcriberservice.staticalvar.StaticVariables;
import vn.com.viettel.subcriberservice.utils.ConfigFileParser;
import vn.com.viettel.subcriberservice.utils.Utils;

public class MainEntry {

    private static Logger logger = LoggerFactory.getLogger(MainEntry.class);
    private static HttpServer httpServer = null;
    private static ExecutorService rpExecutor = null;

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java -jar application_name.jar <config_file>");
            return;
        }

        logger.info("Starting server..............");
        logger.info("Reading and parsing config file..........");
        
        ConfigFileParser cfc = new ConfigFileParser(args[0]);
        if (!cfc.process()) {
            logger.error("Wrong format or miss some critical parameters. Please check config file content again");
            System.exit(1);
            return;
        }
        logger.info("Reading and parsing config file..........done!");

        StaticVariables.myPid = Utils.getCurrentPid();
        logger.info("Starting in VM with pid: " + StaticVariables.myPid);
        logger.info("pid is saved to file: " + StaticVariables.dataFolder
                + StaticVariables.pidFilename);
        Utils.savePid(StaticVariables.myPid, StaticVariables.dataFolder
                + StaticVariables.pidFilename);

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                logger.info("System is shutting down....");
                // close all server connections

                if (httpServer != null) {
                    httpServer.shutdown();
                }

                // delete pid file
                Utils.deleteFile(StaticVariables.dataFolder
                        + StaticVariables.pidFilename);
            }
        });

        logger.info("Start http server at port: "
                + StaticVariables.httpServerPort);
        httpServer = new HttpServer(StaticVariables.httpServerPort);
        httpServer.start();

        while (true) {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
