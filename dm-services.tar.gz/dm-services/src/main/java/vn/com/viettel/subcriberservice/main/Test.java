/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.com.viettel.subcriberservice.main;

import java.util.Date;
import vn.com.viettel.dm.core.util.DecimalUtil;
import vn.com.viettel.dm.core.util.DecimalUtil.TBCDCodec;

/**
 *
 * @author khoimt
 */
public class Test {

	public static void main(String args[]) {
		byte[] tmp = DecimalUtil.TBCDCodec.parseTBCD("849648595");
		System.out.println(DecimalUtil.TBCDCodec.dumpBytes(tmp));

        System.out.println(new Date(1442894400000l).toString());
	}
}
