/**
 * Copyright 2015 Viettel Group. All rights reserved VIETTEL
 * PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.httpserver;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import vn.com.viettel.subcriberservice.constant.Constants;
import vn.com.viettel.subcriberservice.staticalvar.StaticVariables;

/**
 * Khởi tạo luồng xử lý cho service của bên pháp chế
 *
 * @author khoimt
 */
public class HttpServerInitializer extends ChannelInitializer<SocketChannel> {

	@Override
	public void initChannel(SocketChannel ch) {
		ChannelPipeline p = ch.pipeline();
		p.addLast(new HttpRequestDecoder());
		// Uncomment the following line if you don't want to handle HttpChunks.
		p.addLast(new HttpObjectAggregator(10 * 1024 * 1024));
		p.addLast(new HttpResponseEncoder());
		
		p.addLast(new HttpServerHandler());
	}
}
