/**
 * Copyright 2015 Viettel Group. All rights reserved
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.httpserver;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.FullHttpRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Super Service Class
 * @author khoimt
 */
public abstract class Processor implements Runnable {
	public abstract void process(ChannelHandlerContext ctx, FullHttpRequest msg);
	protected ChannelHandlerContext ctx;
	protected FullHttpRequest msg;
	protected static Logger logger = LoggerFactory.getLogger(Processor.class);
	protected static final String ERROR_JSON = "{\"status\" : \"Bad request, please check input parameters\"}";
	
	public Processor(ChannelHandlerContext ctx, FullHttpRequest msg) {
		this.ctx = ctx;
		this.msg = msg.copy();
	}
	
    @Override
	public void run() {
		this.process(ctx, msg);
	}
}
