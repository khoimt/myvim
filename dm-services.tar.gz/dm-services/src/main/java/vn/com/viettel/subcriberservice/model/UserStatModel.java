/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.com.viettel.subcriberservice.model;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.FirstKeyOnlyFilter;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.filter.QualifierFilter;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.SubstringComparator;
import org.apache.hadoop.hbase.util.Bytes;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.viettel.dm.core.util.DecimalUtil;
import vn.com.viettel.subcriberservice.constant.Constants;
import vn.com.viettel.subcriberservice.utils.Utils;

/**
 *
 * @author khoimt
 */
public class UserStatModel extends HTableModel {

	protected static final String userTable = "datamonitoring_hourly_user_stats";
	protected static final Logger logger = LoggerFactory.getLogger(UserStatModel.class);

	public UserStatModel(HConnection connection) {
		super(connection);
	}

	public JSONObject getSubscriberNDaysBytesStatsByMSISDN(String msisdn, long startTime, long endTime) {
		try {
			System.out.println("startTime: " + startTime);
			System.out.println("endTime: " + endTime);
			byte msisdnByte[] = DecimalUtil.TBCDCodec.parseTBCD(msisdn);

			long startHour = Utils.roundHour(startTime),
					stopHour = Utils.roundHour(endTime);
			byte[] startRow = Bytes.add(msisdnByte, Bytes.toBytes(startHour));
			byte[] stopRow = Bytes.add(msisdnByte, Bytes.toBytes(stopHour + 1));

			Scan scan = new Scan();
			scan.setStartRow(startRow);
			scan.setStopRow(stopRow);

			scan.addColumn("cf1".getBytes(), "ub".getBytes());
			scan.addColumn("cf1".getBytes(), "db".getBytes());
			scan.setMaxVersions(1);

			FilterList filter = new FilterList(FilterList.Operator.MUST_PASS_ALL);
			filter.addFilter(new PrefixFilter(msisdnByte));
			scan.setFilter(filter);

			HTableInterface table = con.getTable(userTable);
			ResultScanner rsScan;

			byte[] row, cq, val;
			Map<Integer, Long> dayubStat = new HashMap<>();
			Map<Integer, Long> daydbStat = new HashMap<>();

			rsScan = table.getScanner(scan);
			for (Result r : rsScan) {
				if (r != null && !r.isEmpty()) {
					row = Bytes.copy(r.getRow());
					for (Cell cell : r.rawCells()) {
						cq = CellUtil.cloneQualifier(cell);
						val = CellUtil.cloneValue(cell);
						long ti = Bytes.toLong(row, row.length - 8);
						int d = (int) (ti / Constants.Time.DAY_IN_MILISECOND);

						logger.info("d: {}, ti: {}", d, ti);

						String cqStr = new String(cq);
						if (cqStr.equals("ub")) {
							if (dayubStat.containsKey(d)) {
								long tmp = dayubStat.get(d) + Bytes.toLong(val);
								dayubStat.put(d, tmp);
							} else {
								dayubStat.put(d, Bytes.toLong(val));
							}
						} else if (cqStr.equals("db")) {
							if (daydbStat.containsKey(d)) {
								long tmp = daydbStat.get(d) + Bytes.toLong(val);
								daydbStat.put(d, tmp);
							} else {
								daydbStat.put(d, Bytes.toLong(val));
							}
						}
					}
				}
			}

			logger.info("ubsize: {}, dbsize: {}", dayubStat.size(), daydbStat.size());

			JSONObject obj = new JSONObject();
			JSONArray ubJs = new JSONArray();
			JSONArray dbJs = new JSONArray();
			obj.put("ub", ubJs);
			obj.put("db", dbJs);

			logger.info("---------------");
			if (dayubStat.size() > 0) {
				for (Map.Entry<Integer, Long> entry : daydbStat.entrySet()) {
					logger.info("{} {}", entry.getKey(), entry.getValue());
				}
			}

			int st = (int) (startTime / Constants.Time.DAY_IN_MILISECOND);
			int en = (int) (endTime / Constants.Time.DAY_IN_MILISECOND);
			logger.info("{} {} st: {}, en: {}", startTime, endTime, st, en);

			int counter = 0;
			for (int j = st; j <= en; j++) {
				if (counter++ == 10) {
					break;
				}
				JSONObject tmp = new JSONObject();
				tmp.put("key", new Date(j * Constants.Time.DAY_IN_MILISECOND).toString());
				if (dayubStat.containsKey(j)) {
					tmp.put("value", dayubStat.get(j));
				} else {
					tmp.put("value", 0);
				}
				ubJs.add(tmp);

				tmp = new JSONObject();
				tmp.put("key", new Date(j * Constants.Time.DAY_IN_MILISECOND).toString());
				if (daydbStat.containsKey(j)) {
					tmp.put("value", daydbStat.get(j));
				} else {
					tmp.put("value", 0);
				}
				dbJs.add(tmp);
			}
			return obj;
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
		} finally {
		}
		return null;
	}

	public JSONObject getSubscriberNHoursBytesStatsByMSISDN(String msisdn, long startTime, long endTime) {
		try {
			byte msisdnByte[] = DecimalUtil.TBCDCodec.parseTBCD(msisdn);

			long startHour = Utils.roundHour(startTime),
					stopHour = Utils.roundHour(endTime);
			byte[] startRow = Bytes.add(msisdnByte, Bytes.toBytes(startHour));
			byte[] stopRow = Bytes.add(msisdnByte, Bytes.toBytes(stopHour + 1));

			Scan scan = new Scan();
			logger.info("msisdn: {}", msisdn);
			logger.info("{}", DecimalUtil.TBCDCodec.dumpBytes(
					DecimalUtil.TBCDCodec.parseTBCD(msisdn)));
			scan.setStartRow(msisdnByte);
			scan.setStopRow(stopRow);

			FilterList filter = new FilterList(FilterList.Operator.MUST_PASS_ALL);
			filter.addFilter(new PrefixFilter(msisdnByte));
			scan.setFilter(filter);

			scan.setMaxVersions(1);
			scan.addColumn("cf1".getBytes(), "ub".getBytes());
			scan.addColumn("cf1".getBytes(), "db".getBytes());

			HTableInterface table = con.getTable(userTable);
			ResultScanner rsScan;
			byte[] row, cq, val;
			JSONObject obj = new JSONObject();
			JSONArray ubJs = new JSONArray();
			JSONArray dbJs = new JSONArray();
			obj.put("ub", ubJs);
			obj.put("db", dbJs);

			int i = 0;
			rsScan = table.getScanner(scan);
			for (Result r : rsScan) {
				if (r != null && !r.isEmpty()) {
					row = Bytes.copy(r.getRow());
					for (Cell cell : r.rawCells()) {
						cq = CellUtil.cloneQualifier(cell);
						val = CellUtil.cloneValue(cell);
						long ti = Bytes.toLong(row, row.length - 8);

						JSONObject tmpObj = new JSONObject();

						tmpObj.put("key", new Date(ti).toString());
						String cqStr = new String(cq);
						if (cqStr.equals("ub")) {
							tmpObj.put("value", Bytes.toLong(val));
							ubJs.add(tmpObj);
						} else if (cqStr.equals("db")) {
							tmpObj.put("value", Bytes.toLong(val));
							dbJs.add(tmpObj);
						}
					}
					if (i++ == 10) {
						break;
					}
				}
			}

			return obj;
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
		} finally {
		}
		return null;
	}

	public JSONObject getSubscriber1HourBitRateStatsByMSISDN(String msisdn, long hour) {
		return getSubscriber1HourBitRateStatsByMSISDN(msisdn, hour, -1);
	}

	public JSONObject getSubscriber1HourBitRateStatsByMSISDN(String msisdn,
			long hour, long fromTime) {
		try {
			byte msisdnByte[] = DecimalUtil.TBCDCodec.parseTBCD(msisdn);
			hour = Utils.roundHour(hour);
			logger.info("msisdn hex: " + DecimalUtil.TBCDCodec.byteToTBCDString(msisdnByte));

			byte rowByte[] = Bytes.add(msisdnByte, Bytes.toBytes(hour));
			Get get = new Get(rowByte);
			get.addFamily("cf2".getBytes());

			FilterList filter = new FilterList(FilterList.Operator.MUST_PASS_ALL);
			filter.addFilter(new QualifierFilter(CompareFilter.CompareOp.EQUAL,
					new RegexStringComparator("(ubr|dbr)$")));

			get.setFilter(filter);

			HTableInterface table = con.getTable(userTable);

			byte[] cq, val;
			JSONObject obj = new JSONObject();
			JSONArray ubJs = new JSONArray();
			JSONArray dbJs = new JSONArray();
			obj.put("ubr", ubJs);
			obj.put("dbr", dbJs);

			logger.info(get.toString());

			Result rsGet = table.get(get);
			if (rsGet.isEmpty()) {
				logger.info("result is Empty");
				return obj;
			}

			for (Cell cell : rsGet.listCells()) {
				cq = CellUtil.cloneQualifier(cell);
				val = CellUtil.cloneValue(cell);
				long ti = Bytes.toLong(cq);

				JSONObject tmpObj = new JSONObject();

				tmpObj.put("key", new Date(ti).toString());
				String cqStr = new String(Bytes.copy(cq, cq.length - 3, 3));
				if (cqStr.equals("ubr")) {
					tmpObj.put("value", Bytes.toLong(val));
					ubJs.add(tmpObj);
				} else if (cqStr.equals("dbr")) {
					tmpObj.put("value", Bytes.toLong(val));
					dbJs.add(tmpObj);
				}
			}

			return obj;
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
		} finally {
		}
		return null;
	}

	public JSONObject getSubscriber1HourAvgTcpCrtStatsByMSISDN(String msisdn,
			long hour) {
		return getSubscriber1HourAvgTcpCrtStatsByMSISDN(msisdn, hour, -1);
	}

	public JSONObject getSubscriber1HourAvgTcpCrtStatsByMSISDN(String msisdn,
			long hour, long fromTime) {
		try {
			byte msisdnByte[] = DecimalUtil.TBCDCodec.parseTBCD(msisdn);
			hour = Utils.roundHour(hour);
			logger.info("msisdn hex: " + DecimalUtil.TBCDCodec.byteToTBCDString(msisdnByte));

			byte rowByte[] = Bytes.add(msisdnByte, Bytes.toBytes(hour));
			Get get = new Get(rowByte);
			get.addFamily("cf2".getBytes());

			FilterList filter = new FilterList(FilterList.Operator.MUST_PASS_ALL);
			filter.addFilter(new QualifierFilter(CompareFilter.CompareOp.EQUAL,
					new RegexStringComparator("atc$")));

			get.setFilter(filter);

			HTableInterface table = con.getTable(userTable);

			byte[] cq, val;
			JSONObject obj = new JSONObject();
			JSONArray atc = new JSONArray();
			obj.put("atc", atc);

			logger.info(get.toString());

			Result rsGet = table.get(get);
			if (rsGet.isEmpty()) {
				logger.info("result is Empty");
				return obj;
			}

			for (Cell cell : rsGet.listCells()) {
				cq = CellUtil.cloneQualifier(cell);
				val = CellUtil.cloneValue(cell);
				long ti = Bytes.toLong(cq);

				JSONObject tmpObj = new JSONObject();

				tmpObj.put("key", new Date(ti).toString());
				tmpObj.put("value", Bytes.toLong(val));
				atc.add(tmpObj);
			}

			return obj;
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
		} finally {
		}
		return null;
	}

	JSONObject getSubscriber1HourAvgTcpSrtStatsByMSISDN(String msisdn,
			long hour) {
		return getSubscriber1HourAvgTcpSrtStatsByMSISDN(msisdn, hour, -1);
	}

	JSONObject getSubscriber1HourAvgTcpSrtStatsByMSISDN(String msisdn,
			long hour, long fromTime) {
		try {
			byte msisdnByte[] = DecimalUtil.TBCDCodec.parseTBCD(msisdn);
			hour = Utils.roundHour(hour);
			logger.info("msisdn hex: " + DecimalUtil.TBCDCodec.byteToTBCDString(msisdnByte));

			byte rowByte[] = Bytes.add(msisdnByte, Bytes.toBytes(hour));
			Get get = new Get(rowByte);
			get.addFamily("cf2".getBytes());

			FilterList filter = new FilterList(FilterList.Operator.MUST_PASS_ALL);
			filter.addFilter(new QualifierFilter(CompareFilter.CompareOp.EQUAL,
					new RegexStringComparator("ats$")));

			get.setFilter(filter);

			HTableInterface table = con.getTable(userTable);

			byte[] cq, val;
			JSONObject obj = new JSONObject();
			JSONArray ats = new JSONArray();
			obj.put("ats", ats);

			logger.info(get.toString());

			Result rsGet = table.get(get);
			if (rsGet.isEmpty()) {
				logger.info("result is Empty");
				return obj;
			}

			for (Cell cell : rsGet.listCells()) {
				cq = CellUtil.cloneQualifier(cell);
				val = CellUtil.cloneValue(cell);
				long ti = Bytes.toLong(cq);

				JSONObject tmpObj = new JSONObject();

				tmpObj.put("key", new Date(ti).toString());
				tmpObj.put("value", Bytes.toLong(val));
				ats.add(tmpObj);
			}

			return obj;
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
		} finally {
		}
		return null;
	}

	JSONObject getSubscriberNHoursAccessLogByMSISDN(String msisdn, long startTime, long endTime) {
		try {
			String str = new String(Files.readAllBytes(new File("tmp/tmp_msisdn_day.json").toPath()));
			JSONObject obj = (JSONObject) new JSONParser().parse(str);
//            obj.put("msisdn", params.get("msisdn").get(0));
			return obj;
		} catch (IOException | ParseException ex) {
			logger.error(ex.getMessage(), ex);
		}
		return null;
	}

	void getSample() {
		try {
			Scan scan = new Scan();

			scan.addFamily("cf1".getBytes());
			scan.addFamily("cf2".getBytes());
			scan.setMaxVersions(1);

			FilterList fList = new FilterList(FilterList.Operator.MUST_PASS_ALL);
			fList.addFilter(new FirstKeyOnlyFilter());
			scan.setFilter(fList);

			HTableInterface table = con.getTable(userTable);
			ResultScanner rsScan;
			byte[] row, cq, val;

			rsScan = table.getScanner(scan);
			int rowCounter = 0;
			for (Result r : rsScan) {
				if (r != null && !r.isEmpty()) {
					row = Bytes.copy(r.getRow());
					for (Cell cell : r.rawCells()) {
						cq = CellUtil.cloneQualifier(cell);
						String msisdn = DecimalUtil.TBCDCodec.byteToTBCDString(Bytes.copy(row, 0, row.length - 8));
						long timestamp = Bytes.toLong(row, row.length - 8);
						System.out.println(msisdn + ":" + timestamp);
					}
				}
				if (++rowCounter == 10) {
					break;
				}
			}

			rsScan.close();
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
		} finally {
		}
	}

	public static void main(String args[]) throws IOException {
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.zookeeper.quorum", "sandbox.hortonworks.com");
		conf.set("zookeeper.znode.parent", "/hbase-unsecure");
		conf.setInt("hbase.zookeeper.property.clientPort", 2181);

		HConnection con = HConnectionManager.createConnection(conf);
		UserStatModel model = new UserStatModel(con);
		model.getSample();
		con.close();
	}
}
