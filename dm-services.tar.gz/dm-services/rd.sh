#!/bin/bash

for (( i = 23; i >=0; i--)); do 
# 	for (( j = 55; j >= 0; j=j - 5)); do
# 		printf "{\"23/09/2015 15:%02d:%02d\": %d},\n" $i $j $RANDOM
# 	done
	tmp=$(( $RANDOM * $RANDOM))
	printf "{\"%02d/09/2015\": %d},\n" $i $tmp
done
