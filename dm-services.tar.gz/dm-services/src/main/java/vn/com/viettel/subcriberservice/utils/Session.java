/**
 * Copyright 2015 Viettel Group. All rights reserved
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.utils;

/**
 *
 * @author khoimt
 */
public class Session {

    private String sessionID;
    private long startTime;
    private long stopTime;

    private String ip;
    private int port;
    private String destIP;
    private int destPort;
    private String uid;
    private String privateIP;

    public Session() {
    }

    public void setPrivateIP(String privateIP) {
        this.privateIP = privateIP;
    }

    public String getPrivateIP() {
        return privateIP;
    }

    public void setIP(String IP) {
        this.ip = IP;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public void setStopTime(long stopTime) {
        this.stopTime = stopTime;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getIP() {
        return this.ip;
    }

    public long getStartTime() {
        return startTime;
    }

    public long getStopTime() {
        return stopTime;
    }

    public String getUid() {
        return uid;
    }

    public String getSessionID() {
        return sessionID;
    }

    public String getIp() {
        return ip;
    }

    public int getPort() {
        return port;
    }

    public String getDestIP() {
        return destIP;
    }

    public int getDestPort() {
        return destPort;
    }

    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setDestIP(String destIP) {
        this.destIP = destIP;
    }

    public void setDestPort(int destPort) {
        this.destPort = destPort;
    }

    @Override
    public String toString() {
        return "Session{" + "sessionID=" + sessionID + ", startTime=" + startTime
                + ", stopTime=" + stopTime + ", ip=" + ip + ", port=" + port
                + ", destIP=" + destIP + ", destPort=" + destPort + ", uid=" + uid
                + ", privateIP=" + privateIP + '}';
    }
}
