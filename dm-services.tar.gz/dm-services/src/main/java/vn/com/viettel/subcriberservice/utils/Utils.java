/**
 * Copyright 2015 Viettel Group. All rights reserved
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.utils;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.util.CharsetUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;
import java.util.StringTokenizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.viettel.subcriberservice.constant.Constants;

public class Utils {

    static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static Random rnd = new Random();
    protected static final Logger logger = LoggerFactory.getLogger(Utils.class);

    /**
     * chuyển byte array ra một số nguyên
     * @param b
     * @param offset
     * @return
     */
    public static int byteArrayToInt(byte[] b, int offset) {
        return b[offset + 3] & 0xFF | (b[offset + 2] & 0xFF) << 8
                | (b[offset + 1] & 0xFF) << 16 | (b[offset] & 0xFF) << 24;
    }

    /**
     * sinh một xâu ngẫu nhiên với độ dài len
     * @param len độ dài
     * @return
     */
    public static String randomString(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        }
        return sb.toString();
    }

    /**
     * chuyển số kiểu long ra byte array
     * @param x
     * @return
     */
    public static byte[] longToBytes(long x) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.SIZE / 8);
        buffer.putLong(x);
        return buffer.array();
    }

    /**
     * chuyển byte array ra số long
     * @param bytes
     * @return
     */
    public static long bytesToLong(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.SIZE / 8);
        buffer.put(bytes);
        buffer.flip();
        return buffer.getLong();
    }

    /**
     * chuyển 4 byte array ra IP dạng string
     * @param ip
     * @return
     */
    public static String ipByteArrayToString(byte[] ip) {
        return (ip[0] & 0xFF) + "." + (ip[1] & 0xFF) + "." + (ip[2] & 0xFF) + "." + (ip[3] & 0xFF);
    }

    /**
     * Convert IP from INT to string
     *
     * @param ipInt in INT form
     * @return IP in string
     */
    public static String ipIntToString(int ipInt) {
        return ((ipInt >> 24 & 0xFF) + "." + (ipInt >> 16 & 0xFF) + "." + (ipInt >> 8 & 0xFF) + "." + (ipInt & 0xFF));
    }

    /**
     * Convert IP from string form to byte array
     *
     * @param ip in string form
     * @return IP in byte array form
     */
    public static byte[] ipStringToByteArray(String ip) {
        byte[] b = new byte[4];
        StringTokenizer tokenizer = new StringTokenizer(ip, ".");
        for (int i = 0; i < 4; i++) {
            if (!tokenizer.hasMoreTokens()) {
                return new byte[4];
            }
            String tok = tokenizer.nextToken();
            try {
                b[i] = (byte) Integer.parseInt(tok);
            } catch (Exception ex) {
                return new byte[4];
            }
        }
        return b;
    }

    /**
     * Chuyển số nguyên Int ra byte array
     * @param a
     * @return
     */
    public static byte[] intToByteArray(int a) {
        return new byte[]{(byte) ((a >> 24) & 0xFF),
            (byte) ((a >> 16) & 0xFF), (byte) ((a >> 8) & 0xFF),
            (byte) (a & 0xFF)};
    }

    /**
     *
     * @param b
     * @return
     */
    public static int byteArrayToInt(byte[] b) {
        if (b.length < 4) {
            return 0;
        }
        return b[3] & 0xFF | (b[2] & 0xFF) << 8
                | (b[1] & 0xFF) << 16 | (b[0] & 0xFF) << 24;
    }

    /**
     * chuyển byte array ra số nguyên
     * @param b
     * @return
     */
    public static long byteArrayToLong(byte[] b) {
        if (b.length < 4) {
            return 0;
        }
        return b[7] & 0xFFl | (b[6] & 0xFFl) << 8
                | (b[5] & 0xFFl) << 16 | (b[4] & 0xFFl) << 24
                | (b[3] & 0xFFl) << 32 | (b[2] & 0xFFl) << 40
                | (b[1] & 0xFFl) << 48 | (b[0] & 0xFFl) << 56;
    }

    /**
     * Get current process id. It will help us to stop process easily.
     * @return Process ID
     */
    public static int getCurrentPid() {
        try {
            return Integer.parseInt(ManagementFactory.getRuntimeMXBean()
                    .getName().split("@")[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * Save process id to file
     *
     * @param pid The process id
     * @param filePath path to file
     * @return true if success, false otherwise
     */
    public static boolean savePid(int pid, String filePath) {
		try {
			File tgFile = new File(filePath);
			if (!tgFile.getParentFile().exists()) tgFile.getParentFile().mkdirs();
			BufferedWriter bw = new BufferedWriter(new FileWriter(tgFile));
            bw.write(String.valueOf(pid));
			bw.flush();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Delete file with filePath
     *
     * @param filePath Path to file that needs to be deleted
     * @return true if success, false otherwise
     */
    public static boolean deleteFile(String filePath) {
        try {
            File f = new File(filePath);
            f.deleteOnExit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Write response to client
     *
     * @param jsonContent
     * @param status
     * @param ctx
     */
    public static void writeResponse(String jsonContent, HttpResponseStatus status,
            ChannelHandlerContext ctx) {
        FullHttpResponse response = new DefaultFullHttpResponse(
                HttpVersion.HTTP_1_1, status, Unpooled.copiedBuffer(
                        jsonContent, CharsetUtil.UTF_8));

        response.headers().set(HttpHeaders.Names.CONTENT_TYPE,
                "application/json; charset=UTF-8");

        response.headers().set(HttpHeaders.Names.CONTENT_LENGTH,
                response.content().readableBytes());

        ctx.writeAndFlush(response);
    }

    /**
     * get local host name
     * @return
     */
    public static String getHostName() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            return null;
        }
    }

    /**
     * tính hash md5 của một string
     * @param msg
     * @return
     */
    public static byte[] md5(String msg) {
        try {
            MessageDigest encoder = MessageDigest.getInstance("MD5");
            return encoder.digest(msg.getBytes());
        } catch (NoSuchAlgorithmException ex) {
            logger.error(ex.getMessage(), ex);
        }
        return new byte[]{};
    }

    /**
     * nối nhiều byte array thành 1 byte array
     * @param arr
     * @return
     */
    public static byte[] concatBytes(byte[]... arr) {
        int n = 0;
        for (int i = 0; i < arr.length; i++) {
            n += arr[i].length;
        }

        byte result[] = new byte[n];
        int k = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                result[k++] = arr[i][j];
            }
        }
        return result;
    }

    public static long roundHour(long timestamp) {
        return timestamp / Constants.Time.HOUR_IN_MILISECOND
                * Constants.Time.HOUR_IN_MILISECOND;
    }
}
