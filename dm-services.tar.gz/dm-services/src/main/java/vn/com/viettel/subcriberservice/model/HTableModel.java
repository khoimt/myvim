/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.com.viettel.subcriberservice.model;

import org.apache.hadoop.hbase.client.HConnection;

/**
 *
 * @author khoimt
 */
public class HTableModel {
    protected HConnection con;

    public HTableModel(HConnection connection) {
        con = connection;
    }
}
