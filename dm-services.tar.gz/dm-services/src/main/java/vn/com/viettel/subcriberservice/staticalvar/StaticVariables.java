/**
 * Copyright 2015 Viettel Group. All rights reserved
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.staticalvar;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import vn.com.viettel.subcriberservice.constant.Constants;

import com.datastax.driver.core.PreparedStatement;

public class StaticVariables {
    
    public static final Object mutex = new Object();
	// connection pool
    // slave id: granted from master of chickens
    public static int uid = -1;
    public static long masterLastActive = 0;
    public static int masterId = -1;
    public static int standbyMasterId = -1;

    public static int currentCreatedBuffer = 0;

    public static int loadBalancingMode = Constants.LoadBalancingMode.TOKEN_AWARE_OVER_RR;
    public static int casMode = Constants.DatabaseMode.CAS_CQL_ALONE_MODE;

    public static Map<String, PreparedStatement> preparedStatements = new ConcurrentHashMap<String, PreparedStatement>();
    public static String defaultKPName = "default_kp";

    public static int casPort = 9042;

    // process id
    public static int myPid = -1;

    public static int httpServerPort;

    public static String zkHost;
    public static int zkPort;
    public static String zkNode;

    public static String dataFolder = Constants.GeneralConfiguration.DEFAULT_DATA_FOLDER;
    public static String pidFilename = Constants.GeneralConfiguration.DEFAULT_PID_FILENAME;
    public static String serviceName = Constants.Service.LEGISLATION;

    public static int clientRetriesNumber = 2;
    public static int rpcOperationTimeout = 60000;
    // maximum number of request concurrent, use for An ninh mang
    public static int concurrentRequest = 5;
}
