/**
 * Copyright 2015 Viettel Group. All rights reserved
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.utils;

import java.io.BufferedReader;
import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.com.viettel.subcriberservice.constant.Constants;
import vn.com.viettel.subcriberservice.staticalvar.StaticVariables;

/**
 * Parsing request từ phía client
 * @author khoimt
 */
public class ConfigFileParser {

    private static Logger logger = LoggerFactory.getLogger(ConfigFileParser.class);
    private String configFile;

    public ConfigFileParser(String conf) {
        this.configFile = conf;
    }

    /**
     * Parsing client request
     * @return
     */
    public boolean process() {
        try {
            String content = null;
            try (BufferedReader br = new BufferedReader(new FileReader(
                    this.configFile))) {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();

                while (line != null) {
                    sb.append(line);
                    sb.append(System.lineSeparator());
                    line = br.readLine();
                }
                content = sb.toString();
            }

            JSONParser parser = new JSONParser();
            JSONObject obj = (JSONObject) parser.parse(content);
            Object o = null;

            // http port
            o = obj.get("http_port");
            if (o instanceof String) {
                StaticVariables.httpServerPort = Integer.parseInt((String) o);
            } else if (o instanceof Long) {
                StaticVariables.httpServerPort = (int) (long) o;
            } else if (o instanceof Integer) {
                StaticVariables.httpServerPort = (int) o;
            } else {
                logger.warn("Http port is not set. Use default configuration. "
                        + Constants.GeneralConfiguration.DEFAULT_HTTP_PORT);
            }

            // hbase config
            o = obj.get("hbase.zookeeper.quorum");
            if (o instanceof String) {
                StaticVariables.zkHost = o.toString();
            }

            o = obj.get("hbase.zookeeper.property.clientPort");
            if (o instanceof Long) {
                StaticVariables.zkPort = ((Long) o).intValue();
            }

            o = obj.get("zookeeper.znode.parent");
            if (o instanceof String) {
                StaticVariables.zkNode = o.toString();
            }

            // data folder
            o = obj.get("data_folder");
            if (o instanceof String) {
                StaticVariables.dataFolder = (String) o;
            } else {
                logger.warn("Data folder is not set. Use default configuration. "
                        + Constants.GeneralConfiguration.DEFAULT_DATA_FOLDER);
            }
            // pid file
            o = obj.get("pid_filename");
            if (o instanceof String) {
                StaticVariables.pidFilename = (String) o;
            } else {
                logger.warn("Pid filename is not set. Use default configuration. "
                        + Constants.GeneralConfiguration.DEFAULT_PID_FILENAME);
            }

            // số lần request lại vào hbase khi có lỗi
            if (obj.containsKey("client.retries.number")) {
                StaticVariables.clientRetriesNumber = (int) (long) obj.get("client.retries.number");
            }

            // timeout cho một rpc call vào hbase 
            if (obj.containsKey("rpc.operation.timeout")) {
                StaticVariables.rpcOperationTimeout = (int) (long) obj.get("rpc.operation.timeout");
            }

            // service name cho pháp chế hay an ninh mạng
            o = obj.get("service");
            if (o != null) {
                StaticVariables.serviceName = o.toString();
            } else {
                StaticVariables.serviceName = Constants.Service.LEGISLATION;
            }

            // số request cho phép xử lý đồng thời tại một thời điểm
            o = obj.get("concurent_request");
            if (o != null) {
                if (o instanceof String) {
                    StaticVariables.concurrentRequest = Integer.valueOf(o.toString());
                } else {
                    StaticVariables.concurrentRequest = (int) (long) o;
                }
            }

            return true;
        } catch (Exception e) {
            logger.error("Cannot read file or parse json format. Error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String args[]) {
        ConfigFileParser cfc = new ConfigFileParser("/home/william/Desktop/slave.conf");
        cfc.process();
    }

}
