/**
 * Copyright 2015 Viettel Group. All rights reserved
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.constant;

public class Constants {
    public static class Service {
        public static final String LEGISLATION = "legislation";
        public static final String NETWORK_SECURITY = "network_security";
    }

    public static class Time {
        public static final int HOUR_IN_MILISECOND = 3600000;
        public static final int DAY_IN_MILISECOND = 86400000;
    }

	public static class HBaseConstant {
		public static final byte[] DEFAULT_COLUMN_FAMILY_NAME = "dcf"
				.getBytes();
		public static final byte[] DEFAULT_COLUMN_QUALIFIER_NAME = "dcq"
				.getBytes();
		public static final byte[] DEFAULT_TEMP_COLUMN_QUALIFIER_NAME = "dcqv"
				.getBytes();
		public static final byte[] DEFAULT_TEMP_CQ_PREFIX = "v".getBytes();

		public static final String NGRAM_TABLE_NAME = "ngram_tbl";
		public static final byte[] NGRAM_FORUM_CQ_NAME = "F".getBytes();
		public static final byte[] NGRAM_WEB_CQ_NAME = "W".getBytes();
		public static final byte[] NGRAM_SOCIAL_CQ_NAME = "S".getBytes();
		public static final byte[] NGRAM_CF_NAME = "F".getBytes();
		// NEW IN 0.6
		public static final String SUFFIX_TIME_INDEX = "_T_IDX";
		public static final String SUFFIX_DOMAIN_INDEX = "_S_IDX";
		// version 0.12
		public static final String SUFFIX_USER_TO_ID = "_US2I";
		public static final String SUFFIX_URL_TO_ID = "_UR2I";
		public static final String SUFFIX_OWNER_TO_POST = "_O2P";
		public static final String SUFFIX_COMMENT_TO_POSTID = "_C2P";
		
		public static final String FILEINFO_ID_TBL = "fit";
		public static final String FILEINFO_HASH_TBL = "fht";
		public static final String FILEINFO_NAME_TBL = "fnt";
		public static final String FILEINFO_FROM_TO_TBL = "fftt";
		
		public static final String UID_IP_TABLENAME = "ui_tbl";
		public static final String NAT_UID_IP_TABLENAME = "nat_ui_tbl";
		public static final String NAT_IP_UID_TABLENAME = "nat_iu_tbl";
		public static final String IP_UID_TABLENAME = "iu_tbl";
		
		public static final String BLOCKEDlOG_TABLE = "up_blockedlog_tbl";
	}

	public static class GeneralConfiguration {
		public static final int MAX_QUEUE_SIZE = 500000;
		// If current minute equals to MAX_MINUTE, new hdfs files will be
		// created.
		public static final int MAX_MINUTE = 59;
		public static final int MIN_MINUTE = 1;
		public static final int DEFAULT_MAX_PARTITION = 32;
		public static final int MAX_TRIES_HADOOP_WORKER = 5;
		// redis
		public static final String DEFAULT_REDIS_HOST = "nn";
		public static final int DEFAULT_REDIS_PORT = 6381;
		public static final int DEFAULT_MASTER_PORT = 8080;
		public static final int DEFAULT_BINARY_PORT = 1259;
		public static final int DEFAULT_HTTP_PORT = 7895;
		public static final String DEFAULT_NODE_NAME = "node-x";
		public static final String DEFAULT_RUNNING_HOST = "192.168.8.3";
		// zk
		public static final String DEFAULT_ZK_HOST = "nn";
		public static final int DEFAULT_ZK_PORT = 2181;
		public static final int DEFAULT_NO_WORKERS = 2;

		public static final String DEFAULT_MASTER_HOST = "localhost";

		public static final int DEFAULT_MAX_HADOOP_WRITER = 5;
		public static final String DEFAULT_DATA_FOLDER = "/home/william/Desktop";
		public static final String DEFAULT_PID_FILENAME = "proxy.pid";
		public static final int DEFAULT_MAX_TIMEOUT = 15000; // 10 seconds
		public static final int DEFAULT_MAX_UID_TIMEOUT = 20000; // 20 seconds
		public static final String UPDATE_MONITORING = "INSERT INTO %s (DATE, SERVICE_NAME, MESSAGES) VALUES (?, ?, ?)";

		public static class RunningMode {
			public static final int HBASE_MODE = 1;
			public static final int REDIS_MODE = 2;
			public static final int UID_MODE = 4;
			public static final int NEXT1_MODE = 8;
			public static final int NEXT2_MODE = 16;
			public static final int NEXT3_MODE = 32;
		}
		
		public static final int MAX_INPUT_QUEUE_SIZE = 1000000;
		
		public static final int DEFAULT_LIMIT = 1000;
	}

	public static class CassandraConstants {
		public static final String DEFAULT_KP_NAME = "nfw";
		public static final String USER_IP_TABLE = "user_ip_info";
		public static final String IP_USER_TABLE = "ip_user_info";
		public static final String BLOCKED_LOG_TABLE = "blocked_log";

		public static final String UID_IP_TABLENAME = "user_ip_tbl";
		public static final String IP_UID_TABLENAME = "ip_user_tbl";

		public static class UserLogConstants {
			public static final int UID_TYPE = 0;
			public static final int IP_TYPE = 1;
		}
	}

	public class Default {
		public static final String DEFAULT_TABLE_KEY_COL = "key";
		public static final String DEFAULT_TABLE_VAL_COL = "value";
		public static final String DEFAULT_HASH_ID_COL = "id";
		// meta data
		public static final String DEFAULT_META_KS_NAME = "db_proxy_meta_ks";
		public static final String DEFAULT_META_TBL_NAME = "meta_table";
		public static final String DEFAULT_META_TBL_COL = "table_name";
		public static final String DEFAULT_META_KP_COL = "kp";
		public static final String DEFAULT_META_TYPE_COL = "table_type";
	}

	public class LoadBalancingMode {
		public static final int ROUND_ROBIN_ONLY = 0;
		public static final int TOKEN_AWARE_OVER_RR = 1;
	}

	public static class RedisConstants {
		public static final String NEW_URL_LIST = "N_L";
		public static final byte[] NEW_URL_LIST_BYTE = "N_L".getBytes();
		public static final String PENDDING_URL_LIST = "P_L";
		public static final byte[] PENDDING_URL_LIST_BYTE = "P_L".getBytes();
	}

	public static class Log {
		public static class LogLevel {
			public static final int INFO = 1, DEBUG = 2, WARNING = 3,
					ERROR = 4;
		}
	}

	public static class ZookeeperConstants {
		public static final String PROXY_NODE_NAME = "uid_proxies";
	}

	public static class SocialDataType {
		public static final int USER_NAME_MESSAGE_TYPE = 1;
		public static final int USER_URL_MESSAGE_TYPE = 2;
		public static final int POST_TYPE = 3;
		public static final int COMMENT_TYPE = 4;
	}

	public static class RetCode {
		public static final int SUCCESS = 0;
		public static final int INTERNAL_ERROR = 1;
		public static final int VALUE_NOT_FOUND_ERROR = 2;
		public static final int INPUT_ERROR = 3;
	}

	public static class MasterClientCode {
		public static class RequestCode {
			public static final int PING_MSG = 100001;
			public static final int JOIN_CLUSTER_MESSAGE = 100002;
			public static final int GET_HADOOP_INFO = 100003;
			public static final int GET_LIST_PROXY_INFO = 100004;
		}

		public static class ResponseCode {
			public static final int RET_PING_MSG_SUCCESS = 200001;
			public static final int RET_PING_MSG_ERROR = 200002;
			public static final int RET_JOIN_CLUSTER_MESSAGE_SUCCESS = 200003;
			public static final int RET_JOIN_CLUSTER_MESSAGE_ERROR = 200004;
			public static final int RET_GET_HADOOP_INFO_SUCCESS = 200005;
			public static final int RET_GET_HADOOP_INFO_ERROR = 200006;
			public static final int RET_GET_LIST_PROXY_INFO_SUCCESS = 200007;
			public static final int RET_GET_LIST_PROXY_INFO_ERROR = 200008;
		}
	}

	public static class ErrorCode {
		public static final int ERROR_SUCCESS = 0;
		public static final int PARSE_INPUT_MESSAGE_ERROR = 100;
		public static final int EMPTY_FREE_PARTITION_LIST_ERROR = 101;
		public static final int TOPIC_OR_PARTITION_NOT_FOUND = 102;
		public static final int TABLE_NOT_EXISTED = 103;
		public static final int INTERNAL_ERROR = 104;

		public static final int PROXY_NO_NODE = 1, PROXY_CONNECTION_ERROR = 2,
				PROXY_KEY_NOT_EXIST = 3, PROXY_ITEM_NOT_EXIST = 4,
				PROXY_TYPE_ERROR = 5, PROXY_DATA_ERROR = 6,
				PROXY_SET_ERROR = 7, PROXY_NOT_SUPPORT = 8, PROXY_TIMEOUT = 9,
				PROXY_INPUT_ERROR = 10, PROXY_OTHER_ERROR = 11,
				PROXY_MULTI_FIELDS_NOT_EXIST = 12, PROXY_FIELD_NOT_EXIST = 13;

	}

	public class DatabaseMode {
		public static final int CAS_CQL_ALONE_MODE = 0;
		public static final int CAS_OLD_THRIFT_MODE = 1;
	}

	public static class ClientCode {
		public static class ClientCodeRequest {
			public static final int GET_REQUEST = 100001;
			public static final int SET_REQUEST = 100002;
			public static final int MGET_REQUEST = 100003;
			public static final int MSET_REQUEST = 100004;
			public static final int GET_RANGE_REQUEST = 100005;
			public static final int GET_RANGE_WITH_COLUMN_REQUEST = 100006;
			public static final int SET_WITH_COLUMN_REQUEST = 100007;
			public static final int DEL_REQUEST = 100008;
			public static final int MDEL_REQUEST = 100009;
			public static final int MGET_WITH_COLUMN_REQUEST = 100010;
			public static final int MSET_WITH_COLUMN_REQUEST = 100011;
			public static final int HGET_REQUEST = 100012;
			public static final int HGET_RANGE_REQUEST = 100013;
			public static final int HGET_ALL_REQUEST = 100014;
			public static final int HSET_REQUEST = 100015;
			public static final int HMSET_REQUEST = 100016;
			public static final int HMGET_REQUEST = 100017;

			// ADD NEW IN VERSION 0.3
			public static final int MSET_MULTI_COL_REQUEST = 100018;

			// ADD NEW IN VERSION 0.4
			public static final int CHECK_COLUMN_EXISTS_REQUEST = 100019;
			public static final int CHECK_KEY_EXISTS_REQUEST = 100020;
			public static final int GET_LONG_VALUE_REQUEST = 100021;
			public static final int ADD_LONG_VALUE_REQUEST = 100022;
			public static final int MADD_LONG_VALUE_REQUEST = 100023;
			public static final int MGET_LONG_VALUE_REQUEST = 100024;

			// public static final int MGET_MANY_COLUMN_REQUEST = 100018;
			// public static final int MSET_ONE_COLUMN_REQUEST = 100019;
			public static final int NGRAM_GET_REQUEST = 100101;
			public static final int NGRAM_ADD_REQUEST = 100102;
			public static final int NGRAM_SET_REQUEST = 100103;
			public static final int NGRAM_MSET_REQUEST = 100104;
			public static final int NGRAM_MADD_REQUEST = 100105;
			public static final int NGRAM_MGET_REQUEST = 100106;
			public static final int NGRAM_GET_RANGE_BY_COUNT_REQUEST = 100107;
			public static final int NGRAM_GET_RANGE_BY_KEY_REQUEST = 100108;
			public static final int NGRAM_GET_TOP_NGRAM_REQUEST = 100109;
			public static final int NGRAM_RESET_REQUEST = 100110;

			// new in version 0.3
			public static final int GET_NEW_URL_REQUEST = 100201;
			public static final int CONFIRM_URL_REQUEST = 100202;

			// new in version 0.5
			public static final int GET_ALL_KEY_FROM_TABLE = 100501;
			// public static final int GET_ALL_KEY_BY_TIME = 100601;
			// public static final int GET_ALL_KEY_BY_SITE = 100701;

			// version 0.8
			public static final int GET_ALL_VALUE_BY_KEY = 100751;
			public static final int GET_ALL_URL_BY_TIME = 100752;
			public static final int GET_ALL_URL_BY_DOMAIN = 100753;

			// version 0.10
			public static final int GET_VERSIONED_DATA = 100801;
			public static final int MGET_VERSIONED_DATA = 100802;
			// version 0.11
			public static final int SET_LONG_VALUE_REQUEST = 100811;
			public static final int MSET_LONG_VALUE_REQUEST = 100812;

			// version 0.12
			public static final int GET_ALL_INFO_BY_UNAME = 100851;
			public static final int GET_ALL_INFO_BY_UURL = 100852;
			public static final int GET_ALL_POSTS_BY_OWNER_ID = 100853;
			public static final int FB_GET_ALL_POSTS_BY_ACTOR_ID = 100854;
			public static final int GET_ALL_COMMENTS_BY_POST_ID = 100855;

			// version 0.8 - Add cassandra client
			public static final int C_INSERT_USER_INFO_REQUEST = 50100;
			public static final int C_UPDATE_IP_REQUEST = 50101;
			public static final int C_UPDATE_TIME_REQUEST = 50102;
			public static final int C_UPDATE_END_TIME_REQUEST = 50103;
			public static final int C_UPDATE_BLOCKED_LOG_REQUEST = 50104;
			public static final int C_UPDATE_COUNT_REQUEST = 50105;
			public static final int C_GET_INFO_FROM_USER_REQUEST = 50106;
			public static final int C_GET_INFO_FROM_IP_REQUEST = 50107;
			public static final int C_GET_VIOLATED_USER_REQUEST = 50108;
			// version 0.8.5
			public static final int C_UPDATE_USERINFO_REQUEST = 50201;
			public static final int C_GET_USERINFO_REQUEST = 50202;
			// version 0.8.9
			public static final int C_UPDATE_USERINFO_NAT_REQUEST = 50203;

			// version 0.8.6
			public static final int FILE_INFO_SET_REQUEST = 50301;
			public static final int FILE_INFO_GET_BYNAME_REQUEST = 50302;
			public static final int FILE_INFO_GET_BYHASH_REQUEST = 50303;
			public static final int FILE_INFO_SCAN_REQUEST = 50304;
			public static final int FILE_INFO_GET_BYID_REQUEST = 50305;
			
			// version 0.8.8
			public static final int B_SET_BLOCKEDLOG_REQUEST = 50401;
			public static final int B_GET_BLOCKEDLOG_REQUEST = 50402;
		}

		public static class ClientReturnCode {
			public static final int RET_GET_REQUEST_SUCCESS = 200001;
			public static final int RET_GET_REQUEST_ERROR = 200002;
			public static final int RET_SET_REQUEST_SUCCESS = 200003;
			public static final int RET_SET_REQUEST_ERROR = 200004;
			public static final int RET_MGET_REQUEST_SUCCESS = 200005;
			public static final int RET_MGET_REQUEST_ERROR = 200006;
			public static final int RET_MSET_REQUEST_SUCCESS = 200007;
			public static final int RET_MSET_REQUEST_ERROR = 200008;
			public static final int RET_GET_REANGE_REQUEST_SUCCESS = 200009;
			public static final int RET_GET_REANGE_REQUEST_ERROR = 200010;
			public static final int RET_GET_RANGE_WITH_COLUMN_REQUEST_SUCCESS = 200011;
			public static final int RET_GET_RANGE_WITH_COLUMN_REQUEST_ERROR = 200012;
			public static final int RET_SET_WITH_COLUMN_REQUEST_SUCCESS = 200013;
			public static final int RET_SET_WITH_COLUMN_REQUEST_ERROR = 200014;
			public static final int RET_DEL_REQUEST_SUCCESS = 200015;
			public static final int RET_DEL_REQUEST_ERROR = 200016;
			public static final int RET_MDEL_REQUEST_SUCCESS = 200017;
			public static final int RET_MDEL_REQUEST_ERROR = 200018;
			public static final int RET_MGET_WITH_COLUMN_REQUEST_SUCCESS = 200019;
			public static final int RET_MGET_WITH_COLUMN_REQUEST_ERROR = 200020;
			public static final int RET_MSET_WITH_COLUMN_REQUEST_SUCCESS = 200021;
			public static final int RET_MSET_WITH_COLUMN_REQUEST_ERROR = 200022;
			public static final int RET_HGET_REQUEST_SUCCESS = 200023;
			public static final int RET_HGET_REQUEST_ERROR = 200024;
			public static final int RET_HGET_RANGE_REQUEST_SUCCESS = 200025;
			public static final int RET_HGET_RANGE_REQUEST_ERROR = 200026;
			public static final int RET_HGET_ALL_REQUEST_SUCCESS = 200027;
			public static final int RET_HGET_ALL_REQUEST_ERROR = 200028;
			public static final int RET_HSET_REQUEST_SUCCESS = 200029;
			public static final int RET_HSET_REQUEST_ERROR = 200030;
			public static final int RET_HMSET_REQUEST_SUCCESS = 200031;
			public static final int RET_HMSET_REQUEST_ERROR = 200032;
			public static final int RET_HMGET_REQUEST_SUCCESS = 200033;
			public static final int RET_HMGET_REQUEST_ERROR = 200034;

			// ADD NEW IN VERSION 0.3
			public static final int RET_MSET_MULTI_COL_REQUEST_SUCCESS = 200035;
			public static final int RET_MSET_MULTI_COL_REQUEST_ERROR = 200036;

			// ADD NEW IN VERSION 0.4
			public static final int RET_CHECK_COLUMN_EXISTS_REQUEST_SUCCESS = 200037;
			public static final int RET_CHECK_COLUMN_EXISTS_REQUEST_ERROR = 200038;
			public static final int RET_CHECK_KEY_EXISTS_REQUEST_SUCCESS = 200039;
			public static final int RET_CHECK_KEY_EXISTS_REQUEST_ERROR = 200040;
			public static final int RET_GET_LONG_VALUE_REQUEST_SUCCESS = 200041;
			public static final int RET_GET_LONG_VALUE_REQUEST_ERROR = 200042;
			public static final int RET_ADD_LONG_VALUE_REQUEST_SUCCESS = 200043;
			public static final int RET_ADD_LONG_VALUE_REQUEST_ERROR = 200044;
			public static final int RET_MADD_LONG_VALUE_REQUEST_SUCCESS = 200045;
			public static final int RET_MADD_LONG_VALUE_REQUEST_ERROR = 200046;
			public static final int RET_MGET_LONG_VALUE_REQUEST_SUCCESS = 200047;
			public static final int RET_MGET_LONG_VALUE_REQUEST_ERROR = 200048;

			public static final int RET_NGRAM_GET_REQUEST_SUCCESS = 200201;
			public static final int RET_NGRAM_GET_REQUEST_ERROR = 200202;
			public static final int RET_NGRAM_ADD_REQUEST_SUCCESS = 200203;
			public static final int RET_NGRAM_ADD_REQUEST_ERROR = 200204;
			public static final int RET_NGRAM_SET_REQUEST_SUCCESS = 200205;
			public static final int RET_NGRAM_SET_REQUEST_ERROR = 200206;
			public static final int RET_NGRAM_MSET_REQUEST_SUCCESS = 200207;
			public static final int RET_NGRAM_MSET_REQUEST_ERROR = 200208;
			public static final int RET_NGRAM_MADD_REQUEST_SUCCESS = 200209;
			public static final int RET_NGRAM_MADD_REQUEST_ERROR = 200210;
			public static final int RET_NGRAM_MGET_REQUEST_SUCCESS = 200211;
			public static final int RET_NGRAM_MGET_REQUEST_ERROR = 200212;
			public static final int RET_NGRAM_GET_RANGE_BY_COUNT_REQUEST_SUCCESS = 200213;
			public static final int RET_NGRAM_GET_RANGE_BY_COUNT_REQUEST_ERROR = 200214;
			public static final int RET_NGRAM_GET_RANGE_BY_KEY_REQUEST_SUCCESS = 200215;
			public static final int RET_NGRAM_GET_RANGE_BY_KEY_REQUEST_ERROR = 200216;
			public static final int RET_NGRAM_GET_TOP_NGRAM_REQUEST_SUCCESS = 200217;
			public static final int RET_NGRAM_GET_TOP_NGRAM_REQUEST_ERROR = 200218;
			public static final int RET_NGRAM_RESET_REQUEST_SUCCESS = 200219;
			public static final int RET_NGRAM_RESET_REQUEST_ERROR = 200220;

			// new in version 0.3
			public static final int RET_GET_NEW_URL_REQUEST_SUCCESS = 200501;
			public static final int RET_GET_NEW_URL_REQUEST_ERROR = 200502;
			public static final int RET_CONFIRM_URL_REQUEST_SUCCESS = 200503;
			public static final int RET_CONFIRM_URL_REQUEST_ERROR = 200504;

			// new in version 0.5
			public static final int RET_GET_ALL_KEY_FROM_TABLE_SUCCESS = 200901;
			public static final int RET_GET_ALL_KEY_FROM_TABLE_ERROR = 200902;
			// public static final int RET_GET_ALL_KEY_BY_TIME_SUCCESS = 201001;
			// public static final int RET_GET_ALL_KEY_BY_TIME_ERROR = 2001002;
			// public static final int RET_GET_ALL_KEY_BY_SITE_SUCCESS = 201101;
			// public static final int RET_GET_ALL_KEY_BY_SITE_ERROR = 201102;

			// NEW IN VERSION 0.8
			public static final int RET_GET_ALL_VALUE_BY_KEY_SUCCESS = 201103;
			public static final int RET_GET_ALL_VALUE_BY_KEY_ERROR = 201104;
			public static final int RET_GET_ALL_URL_BY_TIME_SUCCESS = 201105;
			public static final int RET_GET_ALL_URL_BY_TIME_ERROR = 201106;
			public static final int RET_GET_ALL_URL_BY_DOMAIN_SUCCESS = 201107;
			public static final int RET_GET_ALL_URL_BY_DOMAIN_ERROR = 201108;

			// version 0.10
			public static final int RET_GET_VERSIONED_DATA_SUCCESS = 201151;
			public static final int RET_GET_VERSIONED_DATA_ERROR = 201152;
			public static final int RET_MGET_VERSIONED_DATA_SUCCESS = 201153;
			public static final int RET_MGET_VERSIONED_DATA_ERROR = 201154;

			// version 0.11
			public static final int RET_SET_LONG_VALUE_REQUEST_SUCCESS = 201155;
			public static final int RET_SET_LONG_VALUE_REQUEST_ERROR = 201156;
			public static final int RET_MSET_LONG_VALUE_REQUEST_SUCCESS = 201157;
			public static final int RET_MSET_LONG_VALUE_REQUEST_ERROR = 201158;

			// version 0.12
			public static final int RET_GET_ALL_INFO_BY_UNAME_SUCCESS = 201201;
			public static final int RET_GET_ALL_INFO_BY_UNAME_ERROR = 201202;
			public static final int RET_GET_ALL_INFO_BY_UURL_SUCCESS = 201203;
			public static final int RET_GET_ALL_INFO_BY_UURL_ERROR = 201204;
			public static final int RET_GET_ALL_POSTS_BY_WALL_ID_SUCCESS = 201205;
			public static final int RET_GET_ALL_POSTS_BY_WALL_ID_ERROR = 201206;
			public static final int RET_FB_GET_ALL_POSTS_BY_ACTOR_ID_SUCCESS = 201207;
			public static final int RET_FB_GET_ALL_POSTS_BY_ACTOR_ID_ERROR = 201208;
			public static final int RET_GET_ALL_COMMENTS_BY_POST_ID_SUCCESS = 201209;
			public static final int RET_GET_ALL_COMMENTS_BY_POST_ID_ERROR = 201210;

			// unknown
			public static final int UNKNOWN_REQUEST_RESPONSE = 300001;
			public static final int PROCESS_ERROR_REPSONSE = 300002;

			// version 0.8
			public static final int RET_C_INSERT_USER_INFO_REQUEST_SUCCESS = 1000300;
			public static final int RET_C_INSERT_USER_INFO_REQUEST_ERROR = 1000301;
			public static final int RET_C_UPDATE_IP_REQUEST_SUCCESS = 1000302;
			public static final int RET_C_UPDATE_IP_REQUEST_ERROR = 1000303;
			public static final int RET_C_UPDATE_TIME_REQUEST_SUCCESS = 1000304;
			public static final int RET_C_UPDATE_TIME_REQUEST_ERROR = 1000305;
			public static final int RET_C_UPDATE_END_TIME_REQUEST_SUCCESS = 1000306;
			public static final int RET_C_UPDATE_END_TIME_REQUEST_ERROR = 1000307;
			public static final int RET_C_UPDATE_BLOCKED_LOG_REQUEST_SUCCESS = 1000308;
			public static final int RET_C_UPDATE_BLOCKED_LOG_REQUEST_ERROR = 1000309;
			public static final int RET_C_UPDATE_COUNT_REQUEST_SUCCESS = 1000310;
			public static final int RET_C_UPDATE_COUNT_REQUEST_ERROR = 1000311;
			public static final int RET_C_GET_INFO_FROM_USER_REQUEST_SUCCESS = 1000312;
			public static final int RET_C_GET_INFO_FROM_USER_REQUEST_ERROR = 1000313;
			public static final int RET_C_GET_INFO_FROM_IP_REQUEST_SUCCESS = 1000314;
			public static final int RET_C_GET_VIOLATED_USER_REQUEST_SUCCESS = 1000315;
			public static final int RET_C_GET_VIOLATED_USER_REQUEST_ERROR = 1000316;

			// version 0.8.5
			public static final int RET_C_UPDATE_USERINFO_REQUEST_SUCCESS = 1000401;
			public static final int RET_C_UPDATE_USERINFO_REQUEST_ERROR = 1000402;
			public static final int RET_C_GET_USERINFO_REQUEST_SUCCESS = 1000403;
			public static final int RET_C_GET_USERINFO_REQUEST_ERROR = 1000404;
			// version 0.8.9
			public static final int RET_C_UPDATE_USERINFO_NAT_REQUEST_SUCCESS = 1000405;
			public static final int RET_C_UPDATE_USERINFO_NAT_REQUEST_ERROR = 1000406;

			// version 0.8.6
			public static final int RET_FILE_INFO_SET_REQUEST_SUCCESS = 1000501;
			public static final int RET_FILE_INFO_SET_REQUEST_ERROR = 1000502;
			public static final int RET_FILE_INFO_GET_BYNAME_REQUEST_SUCCESS = 1000503;
			public static final int RET_FILE_INFO_GET_BYNAME_REQUEST_ERROR = 1000504;
			public static final int RET_FILE_INFO_GET_BYHASH_REQUEST_SUCCESS = 1000505;
			public static final int RET_FILE_INFO_GET_BYHASH_REQUEST_ERROR = 1000506;
			public static final int RET_FILE_INFO_SCAN_REQUEST_SUCCESS = 1000507;
			public static final int RET_FILE_INFO_SCAN_REQUEST_ERROR = 1000508;
			public static final int RET_FILE_INFO_GET_BYID_REQUEST_SUCCESS = 1000509;
			public static final int RET_FILE_INFO_GET_BYID_REQUEST_ERROR = 1000510;

			// version 0.8.8
			public static final int RET_B_SET_BLOCKEDLOG_REQUEST_SUCCESS = 1000601;
			public static final int RET_B_SET_BLOCKEDLOG_REQUEST_ERROR = 1000602;
			public static final int RET_B_GET_BLOCKEDLOG_REQUEST_SUCCESS = 1000603;
			public static final int RET_B_GET_BLOCKEDLOG_REQUEST_ERROR = 1000604;
		}
	}
}
