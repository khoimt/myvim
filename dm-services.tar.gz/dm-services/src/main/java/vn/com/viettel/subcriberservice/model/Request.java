/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.com.viettel.subcriberservice.model;

/**
 *
 * @author khoimt
 */
public class Request {
    boolean blocked;
    private String ip;
    private long timestamp;
    private String uid;
    private String url;

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public String getIp() {
        return ip;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getUid() {
        return uid;
    }

    public String getUrl() {
        return url;
    }
}
