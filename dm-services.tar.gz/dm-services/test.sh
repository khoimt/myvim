#!/bin/bash

# curl 'localhost:7897/dm/msisdn/841630010218400804?action=getSubscriberNDaysBytesStats&lastDay=2015-09-23&N=3'
curl 'localhost:7897/dm/msisdn/841630010218400804?action=getSubscriberNHoursBytesStats&lastHour=2015-09-23&N=3'
