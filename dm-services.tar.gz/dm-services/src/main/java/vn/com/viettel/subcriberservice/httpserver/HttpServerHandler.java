/**
 * Copyright 2015 Viettel Group. All rights reserved VIETTEL
 * PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.httpserver;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.com.viettel.subcriberservice.utils.Utils;

/**
 * Khởi tạo luồng xử lý request
 *
 * @author khoimt
 */
public class HttpServerHandler extends
        SimpleChannelInboundHandler<FullHttpRequest> {

    protected static final String DM_MSISDN = "/dm/msisdn/",
            DM_IMSI = "/dm/imsi/";
    protected static final String ERROR_JSON = "{\"status\" : \"Bad request\"}";

    protected static final Logger logger = LoggerFactory
            .getLogger(HttpServerHandler.class);

    private static final ExecutorService executor = Executors.newCachedThreadPool();

    public HttpServerHandler() {

    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, FullHttpRequest msg)
            throws Exception {
        //routing
        Processor svProcessor = null;
        System.out.println(msg.getUri());
        if (msg.getUri().startsWith(DM_MSISDN)
                || msg.getUri().startsWith(DM_IMSI)) {
            SubcriberProcessor service = new SubcriberProcessor(ctx, msg);
            service.connectHBase();
            svProcessor = service;
            executor.execute(svProcessor);
        } else {
            processError(ctx, msg);
        }
    }

    private void processError(ChannelHandlerContext ctx, FullHttpRequest msg) {
        String jsonContent = ERROR_JSON;
        HttpResponseStatus status = HttpResponseStatus.BAD_REQUEST;
        Utils.writeResponse(jsonContent, status, ctx);

        ctx.writeAndFlush(Unpooled.EMPTY_BUFFER).addListener(
                ChannelFutureListener.CLOSE);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }
}
