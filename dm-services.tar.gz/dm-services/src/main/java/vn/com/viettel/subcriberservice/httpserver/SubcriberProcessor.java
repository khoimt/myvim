/**
 * Copyright 2015 Viettel Group. All rights reserved VIETTEL
 * PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package vn.com.viettel.subcriberservice.httpserver;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http.QueryStringDecoder;
import io.netty.util.CharsetUtil;
import java.io.File;

import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.net.util.SubnetUtils;

import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.json.simple.JSONObject;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import static vn.com.viettel.subcriberservice.httpserver.Processor.logger;
import vn.com.viettel.subcriberservice.staticalvar.StaticVariables;
import vn.com.viettel.subcriberservice.model.Session;
import vn.com.viettel.subcriberservice.model.UserStatModel;

/**
 * Service lookup IP cho bên Pháp chế Tiếp nhận HTTP request, truy vấn vào hbase
 * rồi trả về qủa ở định
 *
 * @author khoimt
 * @version 1.0 dạng JSON
 */
public class SubcriberProcessor extends Processor {

    // bảng chứa dữ liệu adsl và dcom
    protected static final String userTable = "datamonitoring_hourly_user_stats";

    protected Map<String, List<String>> params = new HashMap<>();

    protected static final int DEFAULT_LIMIT = 1000; // mặc định limit 1000 record trả về
    protected static final long DAYms = 86400000l; // Thời gian của một ngày tính theo ms
    // IP pattern
    protected static final String URI_PATTERN
            = "/dm/msisdn/([0-9]+).*";

    protected static final Pattern uriPattern = Pattern.compile(URI_PATTERN);
    // connection vào hbase
    protected HConnection connection;

    protected static List<SubnetUtils> nets;

    protected String destIPFltr; // filtering by destination IP
    protected int destPortFltr, sourcePortFltr;

    protected String content;
    protected long startTime, stopTime; // filtering by time
    protected boolean isContentIP = false; // content is IP or UID
    protected int limit = -1;
    protected long queryTime;

    public static enum QueryType {

        UID_TYPE,
        IP_TYPE,
        AUTO_MODE
    };

    public SubcriberProcessor(ChannelHandlerContext ctx, FullHttpRequest msg) {
        super(ctx, msg);
    }

    /**
     * tạo kết nối vào hbase
     */
    public void connectHBase() {
        try {
            Configuration conf = HBaseConfiguration.create();
            logger.error("{}\n{}\n{}", StaticVariables.zkHost, StaticVariables.zkPort,
                    StaticVariables.zkNode);
            conf.set("hbase.zookeeper.quorum", StaticVariables.zkHost);
            conf.set("zookeeper.znode.parent", StaticVariables.zkNode);
            conf.setInt("hbase.zookeeper.property.clientPort", StaticVariables.zkPort);
            conf.setInt("hbase.client.retries.number", StaticVariables.clientRetriesNumber);
            conf.setInt("hbase.rpc.timeout", StaticVariables.rpcOperationTimeout);

            connection = HConnectionManager.createConnection(conf);
            connection.getTable(userTable);
        } catch (MasterNotRunningException e) {
            logger.error(e.getMessage(), e);
        } catch (ZooKeeperConnectionException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     *
     * @return connection vào hbase
     */
    public HConnection getConnectionHBase() {
        HConnection result = null;
        try {
            Configuration conf = HBaseConfiguration.create();
            conf.set("hbase.zookeeper.quorum", StaticVariables.zkHost);
            conf.set("zookeeper.znode.parent", StaticVariables.zkNode);
            conf.setInt("hbase.zookeeper.property.clientPort", StaticVariables.zkPort);
            conf.setInt("hbase.client.retries.number", StaticVariables.clientRetriesNumber);
            conf.setInt("hbase.rpc.timeout", StaticVariables.rpcOperationTimeout);

            result = HConnectionManager.createConnection(conf);

        } catch (MasterNotRunningException e) {
            logger.error(e.getMessage(), e);
        } catch (ZooKeeperConnectionException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return result;
    }

    String getSubscriberNDaysBytesStats() {
        String lastHour = "2015/09/22";
        int N = 2;
        long startTime = 1442844400000l, endTime = 1442901600000l;
        UserStatModel userModel = new UserStatModel(connection);
        String msisdn = params.get("msisdn").get(0);
        System.out.println(msisdn);
        JSONObject obj = userModel.getSubscriberNDaysBytesStatsByMSISDN(msisdn, startTime, endTime);
        if (obj != null) {
            obj.put("msisdn", msisdn);
            return obj.toJSONString();
        }
        return null;
    }

    String getSubscriberNHoursBytesStats() {
        String lastHour = "2015/09/22";
        int N = 2;
        long startTime = 1443000048039l, endTime = 1443012548039l;
        UserStatModel userModel = new UserStatModel(connection);
        String msisdn = params.get("msisdn").get(0);
        System.out.println(msisdn);
        JSONObject obj = userModel.getSubscriberNHoursBytesStatsByMSISDN(
                                        msisdn, startTime, endTime);
        if (obj != null) {
            obj.put("msisdn", msisdn);
            return obj.toJSONString();
        }
        return null;
    }

    String getSubscriber1HourBitRateStats() {
        String lastHour = "2015/09/22";
        int N = 2;
        long hour = 1442894400000l, fromTime = -1;
        UserStatModel userModel = new UserStatModel(connection);
        String msisdn = params.get("msisdn").get(0);
        System.out.println(msisdn);
        JSONObject obj = userModel.getSubscriber1HourBitRateStatsByMSISDN(msisdn, hour);
                                        
        if (obj != null) {
            obj.put("msisdn", msisdn);
            return obj.toJSONString();
        }
        return null;
    }

    String getSubscriber1HourAvgTcpCrtStats() {
        String lastHour = "2015/09/22";
        int N = 2;
        long hour = 1442894400000l, fromTime = -1;
        UserStatModel userModel = new UserStatModel(connection);
        String msisdn = params.get("msisdn").get(0);
        System.out.println(msisdn);
        JSONObject obj = userModel.getSubscriber1HourAvgTcpCrtStatsByMSISDN(msisdn, hour);
                                        
        if (obj != null) {
            obj.put("msisdn", msisdn);
            return obj.toJSONString();
        }
        return null;
    }

    String getSubscriber1HourAvgTcpSrtStats() {
        String lastHour = "2015/09/22";
        int N = 2;
        long hour = 1442894400000l, fromTime = -1;
        UserStatModel userModel = new UserStatModel(connection);
        String msisdn = params.get("msisdn").get(0);
        System.out.println(msisdn);
        JSONObject obj = userModel.getSubscriber1HourAvgTcpCrtStatsByMSISDN(msisdn, hour);
                                        
        if (obj != null) {
            obj.put("msisdn", msisdn);
            return obj.toJSONString();
        }
        return null;
    }

    String getSubscriberNHoursAccessLog() {
        try {
            String str = new String(Files.readAllBytes(new File("tmp/tmp_msisdn_day.json").toPath()));
            JSONObject obj = (JSONObject) new JSONParser().parse(str);
            obj.put("msisdn", params.get("msisdn").get(0));
            return obj.toJSONString();
        } catch (IOException | ParseException ex) {
            logger.error(ex.getMessage(), ex);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    /**
     * @params
     */
    public void process(ChannelHandlerContext ctx, FullHttpRequest msg) {
        queryTime = System.currentTimeMillis();
        parseRequest();
        logger.info("Start processing");

        if (params.containsKey("action") || params.get("action").size() == 0) {
            String action = params.get("action").get(0);

            String rs = null;

            switch (action) {
                case "getSubscriberNDaysBytesStats":
                    rs = getSubscriberNDaysBytesStats();
                    break;
                case "getSubscriberNHoursBytesStats":
                    rs = getSubscriberNHoursBytesStats();
                    break;
                case "getSubscriber1HourBitRateStats":
                    rs = getSubscriber1HourBitRateStats();
                    break;
                case "getSubscriber1HourAvgTcpCrtStats":
                    rs = getSubscriber1HourAvgTcpCrtStats();
                    break;
                case "getSubscriber1HourAvgTcpSrtStats":
                    rs = getSubscriber1HourAvgTcpSrtStats();
                    break;
                case "getSubscriberNHoursAccessLog":
                    rs = getSubscriberNHoursAccessLog();
                    break;
            }

            if (rs == null || rs.isEmpty()) {
                rs = "{}";
            }

            writeResponse(rs, HttpResponseStatus.OK, ctx);
        } else {
            writeResponse(ERROR_JSON, HttpResponseStatus.OK, ctx);
        }

        ctx.writeAndFlush(Unpooled.EMPTY_BUFFER)
                .addListener(
                        ChannelFutureListener.CLOSE);
        ctx.close();
    }

    boolean check(Session o1, Session o2) {
        return (o1.equals(o2));
    }

    /**
     *
     * @param time epoch time
     * @return String biểu dẫy ngày của time đầu vào theo format YYYYMMDD
     */
    protected static String getDay(long time) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(time);
        return String.format("%04d%02d%02d", cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
        );
    }

    /**
     * bóc tách request nhận từ phía người
     *
     * @param msg - request http từ người dùng
     * @return - parsing body của request, nếu không có lỗi thì trả ra true
     */
    public boolean parseRequest() {
        if (msg.getMethod().equals(HttpMethod.POST)) {
//			ByteBuf buf = msg.content();
//
//			JSONObject obj;
//			try {
//				obj = (JSONObject) (new JSONParser()).parse(buf.toString(CharsetUtil.UTF_8));
//				for (Object key : obj.keySet()) {
//					String k = key.toString();
//					Object o = (Object) obj.get(k);
//
//					switch (k) {
//						case "limit":
//							if (o instanceof Integer) {
//								limit = (int) o;
//							} else if (o instanceof Long) {
//								limit = (int) (long) o;
//							} else if (o instanceof String) {
//								limit = Integer.valueOf(o.toString().trim());
//							}
//							break;
//						case "from":
//							if (o instanceof Long) {
//								startTime = (long) o;
//							} else if (o instanceof String) {
//								startTime = Long.valueOf(o.toString().trim());
//							}
//							break;
//						case "to":
//							if (o instanceof Long) {
//								stopTime = (long) o;
//							} else if (o instanceof String) {
//								stopTime = Long.valueOf(o.toString().trim());
//							}
//							break;
//						case "content":
//							content = o.toString().trim();
//							if (pattern.matcher(content).matches()) {
//								isContentIP = true;
//							} else {
//								isContentIP = false;
//							}
//							break;
//						case "dest_ip":
//							destIPFltr = o.toString().trim();
//							break;
//						case "dest_port":
//							if (o instanceof Long) {
//								destPortFltr = ((Long) o).intValue();
//							} else if (o instanceof String) {
//								destPortFltr = Long.valueOf(o.toString().trim()).intValue();
//							}
//							break;
//						case "source_port":
//							if (o instanceof Long) {
//								sourcePortFltr = ((Long) o).intValue();
//							} else if (o instanceof String) {
//								sourcePortFltr = Long.valueOf(o.toString().trim()).intValue();
//							}
//							break;
//
//						default:
//							break;
//					}
//				}
//			} catch (ParseException ex) {
//				logger.error(ex.getMessage(), ex);
//				return false;
//			} finally {
//			}
//			if (limit == -1) {
//				limit = DEFAULT_LIMIT;
//			}
        } else if (msg.getMethod().equals(HttpMethod.GET)) {
            QueryStringDecoder query = new QueryStringDecoder(msg.getUri());
            Matcher matcher = uriPattern.matcher(msg.getUri());
            params.putAll(query.parameters());
            if (matcher.matches()) {
                params.put("msisdn", Arrays.asList(matcher.group(1)));
            }
        }
        return true;
    }

    /**
     * build kết quả thành một array JSON trả về cho client
     *
     * @param ctx context
     * @param sessions array kết quả
     */
    public void sendResponse(ChannelHandlerContext ctx, List<Session> sessions) {
        JSONObject js = new JSONObject();
        JSONArray arr = new JSONArray();
        JSONObject v;
        if (sessions != null && sessions.size() > 0) {
            for (Session session : sessions) {
                v = new JSONObject();
                if (session.getIP() != null) {
                    v.put("ip", session.getIP());
                }
                if (session.getPort() > 0) {
                    v.put("port", session.getPort());
                }
                if (session.getDestIP() != null) {
                    v.put("dest_ip", session.getDestIP());
                }
                if (session.getDestPort() > 0) {
                    v.put("dest_port", session.getDestPort());
                }
                if (session.getPrivateIP() != null) {
                    v.put("private_ip", session.getPrivateIP());
                }
                v.put("uid", session.getUid());
                v.put("session_id", session.getSessionID());
                v.put("from", session.getStartTime());
                v.put("to", session.getStopTime());

                arr.add(v);
                if (limit > 0 && arr.size() >= limit) {
                    break;
                }
                v = null;
            }
        }
        js.put("result", arr);
        js.put("key", content);
        writeResponse(js.toJSONString(), HttpResponseStatus.OK, ctx);
    }

    /**
     * write chuỗi json kết quả vào context
     *
     * @param jsonContent
     * @param status
     * @param ctx
     */
    protected void writeResponse(String jsonContent, HttpResponseStatus status,
            ChannelHandlerContext ctx) {
        FullHttpResponse response = new DefaultFullHttpResponse(
                HttpVersion.HTTP_1_1, status, Unpooled.copiedBuffer(
                        jsonContent, CharsetUtil.UTF_8));

        response.headers().set(HttpHeaders.Names.CONTENT_TYPE,
                "application/json; charset=UTF-8");

        response.headers().set(HttpHeaders.Names.CONTENT_LENGTH,
                response.content().readableBytes());

        ctx.writeAndFlush(response);
    }
}
